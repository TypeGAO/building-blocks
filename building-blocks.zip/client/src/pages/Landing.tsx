import EnterGame from "../features/enter-game/EnterGame"

function Landing() {
  return (
    <div>
      <EnterGame />
    </div>
  )
}

export default Landing
