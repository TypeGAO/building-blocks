import { Application } from 'express';
//const users = require('./user.js');

const mountRoutes = (app: Application) => {
    //app.use('/users', users);
};
     
module.exports = mountRoutes;
